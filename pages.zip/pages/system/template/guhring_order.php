<?php
    // MICHAEL D. PHILLIPS - 17.04.2026
    // ORDER TEMPLATE PAGE
    require "../../../build/auth.php";
    require "../../../build/functions.php";
    require "../../../build/mailer.php";

    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    // --- HANDLE DELETE (admin only) ---
    if (isset($_GET['delete']) && $_GET['delete'] === '1' && $id > 0) {
        requireRole('admin');

        mysqli_query($conn, "DELETE FROM order_materials WHERE order_id = $id");
        mysqli_query($conn, "DELETE FROM inventory_movements WHERE order_id = $id");
        mysqli_query($conn, "DELETE FROM order_attachments WHERE order_id = $id");
        mysqli_query($conn, "DELETE FROM order_status_history WHERE order_id = $id");

        $del_stmt = mysqli_prepare($conn, "DELETE FROM orders WHERE id = ?");
        if ($del_stmt) {
            mysqli_stmt_bind_param($del_stmt, "i", $id);
            if (mysqli_stmt_execute($del_stmt)) {
                logActivity($conn, $_SESSION['user_id'], 'delete', 'order', $id, "Deleted order #{$id}");
            }
            mysqli_stmt_close($del_stmt);
        }

        header("Location: ../guhring_orders.php");
        exit();
    }

    // --- 1. FETCH MAIN ORDER DATA ---
    $sql = "SELECT * FROM orders WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $order_data = mysqli_stmt_get_result($stmt)->fetch_assoc();

    if (!$order_data) { die("Order not found."); }

    // --- 2. FETCH MATERIALS LINKED TO THIS ORDER ---
    $om_sql = "SELECT material_id, quantity as weight FROM order_materials WHERE order_id = ?";
    $om_stmt = mysqli_prepare($conn, $om_sql);
    mysqli_stmt_bind_param($om_stmt, "i", $id);
    mysqli_stmt_execute($om_stmt);
    $om_res = mysqli_stmt_get_result($om_stmt);
    $order_materials = mysqli_fetch_all($om_res, MYSQLI_ASSOC);

    // --- 3. FETCH ATTACHMENTS ---
    $at_sql = "SELECT file_path FROM order_attachments WHERE order_id = ?";
    $at_stmt = mysqli_prepare($conn, $at_sql);
    mysqli_stmt_bind_param($at_stmt, "i", $id);
    mysqli_stmt_execute($at_stmt);
    $at_res = mysqli_stmt_get_result($at_stmt);
    $attachments = mysqli_fetch_all($at_res, MYSQLI_ASSOC);

    // --- 4. HANDLE FORM SUBMISSION (POST) ---
    if ($_SERVER['REQUEST_METHOD'] === "POST") {
        requireRole('staff'); // viewers can see the order but cannot submit changes
        
        // Calculate Netto weight from the submitted material rows
        $calculated_netto = isset($_POST['weights']) ? array_sum($_POST['weights']) : 0;

        $sub_data = [
            'partner_id'     => $_POST['customer'],
            'type'           => $_POST['type'], // Added type
            'date'           => $_POST['date'],
            'price'          => $_POST['price'],
            'currency'       => $_POST['currency'],
            'pallet_no'      => $_POST['pallet_no'],
            'brutto_w'       => $_POST['brutto_weight'],
            'netto_w'        => $calculated_netto,
            'approve_status' => $_POST['approve_status'],
            'order_status'   => $_POST['order_status']
        ];

        $difference = getChangedFields($order_data, $sub_data);

        if(!empty($difference) || !empty($_POST['materials'])) {
            $changed_summary = [];
            foreach ($difference as $field => $values) {
                $changed_summary[] = "$field ('{$values['from']}' -> '{$values['to']}')";
            }
            $description = "Updated Order: " . implode(", ", $changed_summary);

            // Update main order table - added type=? and updated bind_param string
            $up_sql = "UPDATE orders SET partner_id=?, type=?, date=?, price=?, currency=?, pallet_no=?, brutto_w=?, netto_w=?, approve_status=?, order_status=?, updated_at=NOW() WHERE id=?";
            $up_stmt = mysqli_prepare($conn, $up_sql);
            
            // Param types: i=int, s=string, d=double. 
            // "issdssssssi" maps to the fields in order above.
            mysqli_stmt_bind_param($up_stmt, "issdssssssi", 
                $sub_data['partner_id'], 
                $sub_data['type'], 
                $sub_data['date'], 
                $sub_data['price'], 
                $sub_data['currency'], 
                $sub_data['pallet_no'], 
                $sub_data['brutto_w'], 
                $sub_data['netto_w'], 
                $sub_data['approve_status'], 
                $sub_data['order_status'], 
                $id
            );

            if(mysqli_stmt_execute($up_stmt)) {
                // --- UPDATE MATERIALS TABLE ---
                mysqli_query($conn, "DELETE FROM order_materials WHERE order_id = $id");
                if (!empty($_POST['materials'])) {
                    foreach ($_POST['materials'] as $key => $m_id) {
                        $m_weight = $_POST['weights'][$key];
                        $ins_m = mysqli_prepare($conn, "INSERT INTO order_materials (order_id, material_id, quantity) VALUES (?, ?, ?)");
                        mysqli_stmt_bind_param($ins_m, "iid", $id, $m_id, $m_weight);
                        mysqli_stmt_execute($ins_m);
                    }
                }

                // --- LOG STATUS HISTORY ---
                if (isset($difference['order_status'])) {
                    $hist_sql = "INSERT INTO order_status_history (order_id, status, changed_by) VALUES (?, ?, ?)";
                    $hist_stmt = mysqli_prepare($conn, $hist_sql);
                    mysqli_stmt_bind_param($hist_stmt, "isi", $id, $sub_data['order_status'], $_SESSION['user_id']);
                    mysqli_stmt_execute($hist_stmt);
                }

                // ALSO GOOD TO HAVE LOG ACTIVITY HOW MUCH OF WHAT IS MOVED IN/OUT
                logActivity($conn, $_SESSION['user_id'], 'update', 'orders', $id, $description);

                // --- FETCH PARTNER NAME & SEND EMAIL ---
                $pn_stmt = mysqli_prepare($conn, "SELECT name FROM partners WHERE id = ?");
                mysqli_stmt_bind_param($pn_stmt, "i", $order_data['partner_id']);
                mysqli_stmt_execute($pn_stmt);
                $pn_row = mysqli_stmt_get_result($pn_stmt)->fetch_assoc();
                $partner_name_for_mail = $pn_row['name'] ?? 'Unknown Partner';
                mailOrderUpdated($conn, $id, $order_data, $sub_data, $partner_name_for_mail);
                
                $order_data = array_merge($order_data, $sub_data);
                $success_msg = "Order and materials updated successfully!";
                
                $om_stmt->execute();
                $order_materials = mysqli_fetch_all($om_stmt->get_result(), MYSQLI_ASSOC);
            }
        }

        // ================= INVENTORY MOVEMENTS =================
        mysqli_query($conn, "DELETE FROM inventory_movements WHERE order_id = $id");

        if (!empty($_POST['materials']) && $sub_data['order_status'] === 'completed' && $sub_data['approve_status'] === 'approved') {
            $mov_sql = "INSERT INTO inventory_movements (order_id, material_id, quantity, direction) VALUES (?, ?, ?, ?)";
            $stmt_mov = mysqli_prepare($conn, $mov_sql);

            foreach ($_POST['materials'] as $key => $m_id) {
                $m_weight  = (float)$_POST['weights'][$key];
                $direction = ($sub_data['type'] === 'guh-in') ? 'in' : 'out';

                mysqli_stmt_bind_param($stmt_mov, "iids", $id, $m_id, $m_weight, $direction);
                mysqli_stmt_execute($stmt_mov);
            }
            mysqli_stmt_close($stmt_mov);
        }

        // --- 5. HANDLE FILE UPLOADS ---
        if (!empty($_FILES['documents']['name'][0])) {
            // Determine subfolder based on order type
            $type = $order_data['type'];
            $subfolder = 'in'; // Default

            if ($type === 'out') {
                $subfolder = 'out';
            } elseif ($type === 'guh-in' || $type === 'guh-out') {
                $subfolder = 'guhring';
            }

            // Base path for moving files (relative to this PHP file)
            $upload_base = "../../../order_attachments/" . $subfolder . "/";
            
            // Path to save in DB (relative to site root for the <img> tags)
            $db_base = "order_attachments/" . $subfolder . "/";

            if (!is_dir($upload_base)) {
                mkdir($upload_base, 0777, true);
            }

            foreach ($_FILES['documents']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['documents']['error'][$key] === UPLOAD_ERR_OK) {
                    // Clean filename: timestamp + original name
                    $file_name = time() . "_" . basename($_FILES['documents']['name'][$key]);
                    $target_file = $upload_base . $file_name;
                    $db_path = $db_base . $file_name;

                    if (move_uploaded_file($tmp_name, $target_file)) {
                        $at_ins = mysqli_prepare($conn, "INSERT INTO order_attachments (order_id, file_path) VALUES (?, ?)");
                        mysqli_stmt_bind_param($at_ins, "is", $id, $db_path);
                        mysqli_stmt_execute($at_ins);
                    }
                }
            }
            
            // Refresh attachments list for display
            mysqli_stmt_execute($at_stmt);
            $attachments = mysqli_fetch_all(mysqli_stmt_get_result($at_stmt), MYSQLI_ASSOC);
        }
    }

    // --- FETCH QR-CODE SVG LINKED TO THIS ORDER ---
    $qr_sql = "SELECT file_path FROM order_qrcodes WHERE order_id = ?";
    $qr_stmt = mysqli_prepare($conn, $qr_sql);
    mysqli_stmt_bind_param($qr_stmt, "i", $id);
    mysqli_stmt_execute($qr_stmt);
    $qr_res = mysqli_stmt_get_result($qr_stmt);
    $qr_data = mysqli_fetch_assoc($qr_res);

    // --- 5. FETCH ALL MATERIALS FOR DROPDOWNS ---
    $m_res = mysqli_query($conn, "SELECT id, name FROM materials ORDER BY name ASC");
    $materials = mysqli_fetch_all($m_res, MYSQLI_ASSOC);


    logActivity($conn, $_SESSION['user_id'], 'checking', 'orders', $id, "User #{$_SESSION['user_id']} checked order {$id}");

    $page_title = "GBR ORDER {$id}";
    include "../../../build/header.php";
?>
<script src="../../../js/script.js"></script>
<div class="container-fluid">
    <div class="container-sm">
        <h1>Order Management</h1>
        
        <?php if(isset($success_msg)) echo "<div class='alert alert-success'>$success_msg</div>"; ?>

        <?php $is_viewer = !hasRole('staff'); ?>
        <form method="POST" action="" enctype="multipart/form-data" class="container mt-4">
            <div class="row g-3">

                <div class="col-md-6">
                    <label class="form-label">Customer</label>
                    <select name="customer" class="form-select" required <?= $is_viewer ? 'disabled' : '' ?>>
                        <?php
                            $cust_res = mysqli_query($conn, "SELECT id, name FROM partners");
                            while($cust = mysqli_fetch_assoc($cust_res)) {
                                $selected = ($cust['id'] == $order_data['partner_id']) ? 'selected' : '';
                                echo "<option value='".$cust['id']."' $selected>".$cust['name']."</option>";
                            }
                        ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Select Type</label>
                    <select name="type" class="form-select" required <?= $is_viewer ? 'disabled' : '' ?>>
                        <option value="guh-in" <?php echo ($order_data['type'] == 'guh-in') ? 'selected' : '' ?>>Incoming</option>
                        <option value="guh-out" <?php echo ($order_data['type'] == 'guh-out') ? 'selected' : '' ?>>Outgoing</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Order No</label>
                    <input type="text" name="order_no" class="form-control" disabled value="<?php echo $order_data['order_no']; ?>">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Track ID</label>
                    <input type="text" name="track_id" class="form-control" disabled value="<?php echo $order_data['track_id']; ?>">
                </div>

                <div class="col-md-6">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" required value="<?php echo $order_data['date']; ?>" <?= $is_viewer ? 'readonly' : '' ?>>
                </div>

                <div class="col-md-3 d-none">
                    <label class="form-label">Price</label>
                    <input type="number" inputmode="decimal" pattern="[0-9]*" step="0.01" name="price" class="form-control" required value="<?php echo $order_data['price'] ?>" <?= $is_viewer ? 'readonly' : '' ?>>
                </div>

                <div class="col-md-3 d-none">
                    <label class="form-label">Currency</label>
                    <select name="currency" class="form-select" required <?= $is_viewer ? 'disabled' : '' ?>>
                        <option value="EUR" <?php echo ($order_data['currency'] == "EUR") ? 'selected' : '' ?>>€ EUR</option>
                        <option value="USD" <?php echo ($order_data['currency'] == "USD") ? 'selected' : '' ?>>$ USD</option>
                        <option value="CZK" <?php echo ($order_data['currency'] == "CZK") ? 'selected' : '' ?>>Kč CZK</option>
                        <option value="PLN" <?php echo ($order_data['currency'] == "PLN") ? 'selected' : '' ?>>zł PLN</option>
                        <option value="JPY" <?php echo ($order_data['currency'] == "JPY") ? 'selected' : '' ?>>¥ JPY</option>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Pallet No</label>
                    <input type="text" name="pallet_no" class="form-control" value="<?php echo $order_data['pallet_no'] ?>" <?= $is_viewer ? 'readonly' : '' ?>>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Brutto Weight (kg)</label>
                    <input type="number" inputmode="decimal" pattern="[0-9]*" step="0.01" name="brutto_weight" class="form-control" value="<?php echo $order_data['brutto_w'] ?>" <?= $is_viewer ? 'readonly' : '' ?>>
                </div>

                <div class="col-12">
                    <label class="form-label">Materials</label>
                    <div id="materials-container">
                        <?php 
                        $display_items = !empty($order_materials) ? $order_materials : [['material_id' => '', 'weight' => '']];
                        foreach($display_items as $om): 
                        ?>
                            <div class="row g-2 material-row mb-2 align-items-center">
                                <div class="<?= $is_viewer ? 'col-md-6' : 'col-md-5' ?>">
                                    <select name="materials[]" class="form-select" required <?= $is_viewer ? 'disabled' : '' ?>>
                                        <option value="" disabled <?= empty($om['material_id']) ? 'selected' : '' ?>>Select material</option>
                                        <?php foreach($materials as $m): ?>
                                            <option value="<?= $m['id']; ?>" <?= ($m['id'] == $om['material_id']) ? 'selected' : '' ?>>
                                                <?= $m['name']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="<?= $is_viewer ? 'col-md-6' : 'col-md-3' ?>">
                                    <input type="number" inputmode="decimal" pattern="[0-9]*" step="0.01" name="weights[]" class="form-control weight-input" 
                                           placeholder="Weight (kg)" value="<?= $om['weight']; ?>" required <?= $is_viewer ? 'readonly' : '' ?>>
                                </div>
                                <?php if (!$is_viewer): ?>
                                <div class="col-md-4 d-flex gap-2">
                                    <button type="button" class="btn btn-danger w-50 remove-material">Remove</button>
                                    <button type="button" class="btn btn-success w-50 add-material">+ Add</button>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Netto Weight (kg)</label>
                    <input type="number" inputmode="decimal" pattern="[0-9]*" step="0.01" name="netto_weight" 
                           id="netto_weight" class="form-control" readonly value="<?php echo $order_data['netto_w'] ?>">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Approve Status</label>
                    <select name="approve_status" class="form-select" <?= $is_viewer ? 'disabled' : '' ?>>
                        <option value="approved" <?php echo ($order_data['approve_status'] == 'approved') ? 'selected' : '' ?>>Approved</option>
                        <option value="not approved" <?php echo ($order_data['approve_status'] == 'not approved') ? 'selected' : '' ?>>Not Approved</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Order Status</label>
                    <select name="order_status" class="form-select" <?= $is_viewer ? 'disabled' : '' ?>>
                        <option value="created" <?php echo ($order_data['order_status'] == 'created') ? 'selected' : '' ?>>Created</option>
                        <option value="received" <?php echo ($order_data['order_status'] == 'received') ? 'selected' : '' ?>>Received</option>
                        <option value="in process" <?php echo ($order_data['order_status'] == 'in process') ? 'selected' : '' ?>>In process</option>
                        <option value="completed" <?php echo ($order_data['order_status'] == 'completed') ? 'selected' : '' ?>>Completed</option>
                        <option value="cancelled" <?php echo ($order_data['order_status'] == 'cancelled') ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>

                <div class="col-12 mt-3">
                    <label class="form-label">Documents (Images / PDFs)</label>
                    <?php if (!$is_viewer): ?>
                    <input type="file" name="documents[]" class="form-control mb-2" multiple accept=".jpg,.jpeg,.png,.pdf, .zip, .rar, .7zip">
                    <?php endif; ?>
                    
                    <label class="form-label mt-2"><strong>Existing Attachments:</strong></label>
                    <div class="d-flex flex-wrap gap-2">
                        <?php if(!empty($attachments)): ?>
                            <?php foreach($attachments as $file): ?>
                                <div class="border p-2 rounded bg-light d-flex align-items-center">
                                    <?php 
                                        $ext = pathinfo($file['file_path'], PATHINFO_EXTENSION);
                                        if(in_array(strtolower($ext), ['jpg', 'jpeg', 'png'])): 
                                    ?>
                                        <img src="/<?= $file['file_path'] ?>" style="height: 30px; width: 30px; object-fit: cover;" class="me-2 rounded">
                                    <?php else: ?>
                                        <span class="me-2">📄</span> 
                                    <?php endif; ?>

                                    <a href="/<?= $file['file_path'] ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        View Document
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted small">No documents attached to this order yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-6 mt-4">
                    <label for="" class="form-label"><strong>QR Code</strong></label>
                    <div class="d-flex  flex-wrap flex-column">
                        <?php if (!empty($qr_data)): ?>
                            <a href="/uploads/qrcodes/<?= $qr_data['file_path']; ?>" target="_blank">
                                <img id="qrcode_img" src="/uploads/qrcodes/<?= $qr_data['file_path']; ?>" alt="QR Code" width="150" height="150" class="p-2 border rounded-4">
                            </a>
                            <br>
                            <div class="border p-2 rounded bg-light d-flex align-items-center ms-3" style="width: fit-content;">
                                <a href="#" class="btn btn-sm btn-outline-primary" onclick="printQRCode(); return false;">Print QR Code</a>
                            </div>
                        <?php else: ?>
                            <p class="text-muted small">No QR code generated for this order.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-6 mt-4">
                    <label for="" class="form-label"><strong>Write a Report</strong></label>
                    <div class="d-flex flex-wrap gap-2">
                        <div class="border p-2 rounded bg-light d-flex align-items-center" style="width: fit-content;">
                            <a href="/pages/system/template/report.php?id=<?= $id; ?>" class="btn btn-sm btn-outline-primary" target="_blank">Write a Report</a>
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100 py-2" <?= $is_viewer ? 'disabled' : '' ?>>
                            <?= $is_viewer ? 'View Only — No Edit Access' : 'Update Order & Save Changes' ?>
                        </button>
                        <a href="/pages/system/guhring_orders.php" class="btn btn-secondary w-100 py-2">Back to Orders</a>
                    </div>
                </div>

                <?php if ($id > 0 && hasRole('admin')): ?>
                <div class="col-12 mt-2">
                    <a href="guhring_order.php?id=<?= $id ?>&delete=1" class="btn btn-outline-danger w-100 py-2"
                       onclick="return confirm('Warning: Are you sure you want to permanently delete this order? This action cannot be undone.');">
                        Delete Order
                    </a>
                </div>
                <?php endif; ?>

            </div>
        </form> 
    </div>
</div>

<script>
    function printQRCode() {
        // 1. Grab the element
        const imgElement = document.getElementById('qrcode_img');
        if (!imgElement) return;

        // 2. Get the image source (works if the ID is on the <img> tag or a wrapper div)
        const qrCodeSrc = imgElement.src || imgElement.querySelector('img').src;

        // 3. Open the print window
        const printWindow = window.open('', '_blank');

        printWindow.document.write(`
            <html>
                <head>
                    <title>Print QR Code</title>
                    <style>
                        * {
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        html, body {
                            width: 100%;
                            height: auto;
                            display: flex;
                            justify-content: center;
                            align-items: flex-start;
                        }
                        img {
                            width: 300px;
                            height: 300px;
                            object-fit: contain;
                            display: block;
                        }
                        @media print {
                            @page {
                                size: A4;
                                margin: 10mm;
                            }
                            html, body {
                                width: 100%;
                                height: auto;
                                display: block;
                                text-align: center;
                            }
                            img {
                                width: 250px;
                                height: 250px;
                                page-break-inside: avoid;
                                break-inside: avoid;
                            }
                        }
                    </style>
                </head>
                <body>
                    <img src="${qrCodeSrc}" id="print_target" />
                    <script>
                        document.getElementById('print_target').onload = function() {
                            window.print();
                            window.close();
                        };
                    <\/script>
                </body>
            </html>
        `);

        printWindow.document.close();
    }
</script>

<?php
    include "../../../build/footer.php";
?>